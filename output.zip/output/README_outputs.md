# output.zip -- what is inside (reviewer comment -> file)

figures/ (PNG 300 dpi + PDF)           tables/ (CSV + XLSX + LaTeX)
--------------------------------------------------------------------------------
R1.1 tree ensembles       tables/T01_main_results, T02_statistical_tests, T03a/b, T13_extra_baselines, T08d
                          figures/fig04_cv_boxplots, fig05_roc_pr_calibration, fig08_forest_plot, figS_cd_diagram_*
R1.2 gate values ~0.5     figures/fig_gate_analysis ; tables/T06_gate_interventions, T07a/b_gate_*
R2.1 novelty (evidence)   tables/T05_component_ladder, T04_detailed_ablation ; figures/fig_ablation
R2.2 detailed ablation    tables/T04_detailed_ablation, T05_component_ladder ; figures/fig_ablation
R2.3 hyper-parameters     tables/T08_hyperparameters_full, T08b_pso_search_space, T08c_pso_all_evaluations,
                          T08d_gbdt_random_search_trace, hyperparameters.json, T19_dataset_features
R2.4 concise results      tables/T01_main_results (replaces old Table 2), T02_statistical_tests (replaces old Tables 3+5),
                          T03b (old Table 4), T09_efficiency (old Table 6); figures: fig04, fig05 (replaces old Figs 5+7), fig06, fig08
Explainability            figures/fig09_importance_three_methods, fig10_beeswarm, fig11_explanation_agreement,
                          fig12_local_waterfall, figS_true_shap ; tables/T10_feature_importance, T11_explanation_agreement
Other figures             fig01_dataset_overview (old Fig.1), fig03_pso_convergence (old Fig.3)
Checks I added            tables/T14a/b_nested_pso_*, figures/figS_nested_pso ; T18_reproduction_check_vs_submitted_Table2 ;
                          T15_metrics_at_fixed_threshold_0.5 ; T12_confusion_counts ; T16_bootstrap_ci ; T17_per_fold_metrics
results_summary.json                   every headline number in one machine-readable file
logs/run_log.txt, logs/warnings.txt    full console log and any step that failed
